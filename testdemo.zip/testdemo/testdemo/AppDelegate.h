//
//  AppDelegate.h
//  testdemo
//
//  Created by wangzhewei on 16/2/27.
//  Copyright © 2016年 wangzhewei. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

