//
//  Gauge.m
//  GaugeDemo
//
//  Created by wangzhewei on 12/3/27.
//  Copyright © 2012年 wangzhewei. All rights reserved.
//
#define iPhone5 ([UIScreen instancesRespondToSelector:@selector(currentMode)] ? CGSizeEqualToSize(CGSizeMake(640, 1136), [[UIScreen mainScreen] currentMode].size) : NO)
#define iPhone6 ([UIScreen instancesRespondToSelector:@selector(currentMode)] ? CGSizeEqualToSize(CGSizeMake(750, 1334), [[UIScreen mainScreen] currentMode].size) : NO)
#define iPhone6plus ([UIScreen instancesRespondToSelector:@selector(currentMode)] ? CGSizeEqualToSize(CGSizeMake(1242, 2208), [[UIScreen mainScreen] currentMode].size) : NO)
#define iPhone6PlusZoomMode ([UIScreen instancesRespondToSelector:@selector(currentMode)] ? CGSizeEqualToSize(CGSizeMake(1125, 2001), [[UIScreen mainScreen] currentMode].size) : NO)
#import "Gauge.h"
#import <QuartzCore/QuartzCore.h>
#define MAXOFFSETANGLE 120.0f //remove by liujun
//#define MAXOFFSETANGLE 100.0f
#define POINTEROFFSET  90.0f
#define MAXVALUE       80.0f  //remove by liujun
//#define MAXVALUE       100.0f  //modiy by liujun
#define CELLMARKNUM    10
#define CELLNUM        8
#define DEFLUATSIZE    580

@implementation Gauge

@synthesize gaugeView,pointer,context;
@synthesize labelArray;

-(id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self)
    {
        //设置背景透明
        [self setBackgroundColor:[UIColor clearColor]];
        UIImage *_pointer;
        NSInteger defluatsSize=0;
        
        if (iPhone5) {
            defluatsSize=510;
            _pointer = [UIImage imageNamed:@"pointer_IPHONE4"];
        }else if (iPhone6){


            defluatsSize=560;
            _pointer=[UIImage imageNamed:@"pointer_IPHONE6"];
        }else if (iPhone6plus){

            defluatsSize=600;
            _pointer=[UIImage imageNamed:@"pointer_IPHONE6p"];
        }else if (iPhone6PlusZoomMode){

            defluatsSize=570;
            _pointer=[UIImage imageNamed:@"pointer_IPHONE6"];
        }
        else{

            defluatsSize=510;
            _pointer = [UIImage imageNamed:@"pointer_IPHONE4"];
        }

        



        
        
        UIView *pointerBG=[[UIView alloc]init];
        pointerBG.frame=CGRectMake(0, 0, 65, 65);
        pointerBG.center=self.center;
        pointerBG.layer.cornerRadius=pointerBG.bounds.size.width/2;
        pointerBG.backgroundColor=[UIColor colorWithRed:11/255.0 green:49/255.0 blue:84/255.0 alpha:0.5];
        [self addSubview:pointerBG];
        
        UIView *point=[[UIView alloc]init];
        point.frame=CGRectMake(0, 0, 23, 23);
        point.center=pointerBG.center;
        point.layer.cornerRadius=point.bounds.size.width/2;
        point.backgroundColor=[UIColor colorWithRed:251/255.0 green:77/255.0 blue:83/255.0 alpha:1];
        [self addSubview:point];
        
        scoleNum = (defluatsSize/frame.size.width);
        maxNum = MAXVALUE;
        minNum = 0.0f;
        minAngle = -MAXOFFSETANGLE;
        maxAngle = MAXOFFSETANGLE;
        gaugeValue = 0.0f;
        gaugeAngle = -MAXOFFSETANGLE;
        angleperValue = (maxAngle - minAngle)/(maxNum - minNum);
        
        //添加指针
        pointer = [[UIImageView alloc] initWithImage:_pointer];
        pointer.layer.anchorPoint = CGPointMake(0.5, 0.78);
        pointer.center = self.center;
        pointer.transform = CGAffineTransformMakeScale(scoleNum, scoleNum);
        [self addSubview:pointer];
        //设置文字标签
        [self setTextLabel:CELLNUM];
        //设置指针到0位置
        pointer.layer.transform = CATransform3DMakeRotation([self transToRadian:-MAXOFFSETANGLE], 0, 0,1);
        
        
    }
    return self;
}

/*
 * setTextLabel 绘制刻度值
 * @labelNum NSInteger 刻度值的数目
 */
-(void)setTextLabel:(NSInteger)labelNum
{
    labelArray = [NSMutableArray arrayWithCapacity:labelNum];
    
    CGFloat textDis = (maxNum - minNum)/labelNum;
    CGFloat angelDis = (maxAngle - minAngle)/labelNum;
    CGFloat radius = (self.center.x - 75)*scoleNum;
    CGFloat currentAngle;
    CGFloat currentText = 0.0f;
    CGPoint centerPoint = self.center;
    NSArray *texts=@[@"0",@"256k",@"512k",@"1M",@"5M",@"10M",@"20M",@"50M",@"100+M"];

    
    for(int i=0;i<9;i++)
    {
        currentAngle = minAngle + i * angelDis - POINTEROFFSET;
        currentText = minNum + i * textDis;
        UILabel *label = [[UILabel alloc]initWithFrame:CGRectMake(0 , 0 , 60, 50)];
        label.font=[UIFont fontWithName:@"HelveticaNeue-BoldItalic" size:13];
        label.autoresizesSubviews = YES;
        label.textColor = [UIColor whiteColor];
        label.backgroundColor = [UIColor clearColor];
        //设置刻度的文字的格式
        label.textAlignment = NSTextAlignmentCenter;
        if (i==8) {
          label.textAlignment = NSTextAlignmentRight;
        }
        label.text = [NSString stringWithFormat:@"%@",[texts objectAtIndex:i]];
        NSMutableAttributedString *attrString =
        [[NSMutableAttributedString alloc] initWithString:label.text];
        UIFont *baseFont = [UIFont fontWithName:@"MarkerFelt-Wide" size:15];
        [attrString addAttribute:NSFontAttributeName value:baseFont
                           range:[label.text rangeOfString:@"+"]];
               label.attributedText=attrString;
        label.center = CGPointMake(centerPoint.x+[self parseToX:radius Angle:currentAngle],centerPoint.y+[self parseToY:radius Angle:currentAngle]);
        if (i==4||i==3||i==5) {
            CGPoint point=label.center;
            point.y+=8;
            label.center=point;
        }else if (i==8){
            CGPoint point=label.center;
            point.y-=10;
            label.center=point;
        }else if(i==0){
            CGPoint point=label.center;
            point.y-=8;
            point.x+=7;
            label.center=point;
        }
        
        label.tag=600+i;
        [labelArray addObject:label];
        [self addSubview:label];

    }
}
/*
 * setLineMark 绘制刻度的标记
 * @labelNum NSInteger 刻度是数目
 */
-(void)setLineMark:(NSInteger)labelNum
{
    
    CGFloat angelDis = (maxAngle - minAngle)/labelNum;
    CGFloat radius = self.center.x;
    CGFloat currentAngle;
    CGPoint centerPoint = CGPointMake(self.frame.size.width/2, self.frame.size.height/2);
    
    for(int i=0;i<=labelNum;i++)
    {
        currentAngle = minAngle + i * angelDis - POINTEROFFSET;
        
        //给刻度标记绘制不同的颜色
        if (trigger) {
            //            int type=gaugeValue;
            NSString *typeString=[NSString stringWithFormat:@"%.0lf",gaugeValue];
            int type=[typeString intValue];
            UIColor *color=[UIColor greenColor];
            if (i>=0&&i<2&&type>=1){
                CGContextSetStrokeColorWithColor(context, [color CGColor]);
            }else if (i>1&&i<3&&type>=2) {
                CGContextSetStrokeColorWithColor(context, [color CGColor]);
            }else if (i>2&&i<4&&type>=3) {
                CGContextSetStrokeColorWithColor(context, [color CGColor]);
            }else if (i>3&&i<5&&type>=4) {
                CGContextSetStrokeColorWithColor(context, [color CGColor]);
            }else if (i>4&&i<6&&type>=5) {
                CGContextSetStrokeColorWithColor(context, [color CGColor]);
            }else if (i>5&&i<7&&type>=6) {
                CGContextSetStrokeColorWithColor(context, [color CGColor]);
            }else if (i>6&&i<8&&type>=7) {
                CGContextSetStrokeColorWithColor(context, [color CGColor]);
            }else if (i>7&&i<9&&type>=8) {
                CGContextSetStrokeColorWithColor(context, [color CGColor]);
            }else if (i>8&&i<10&&type>=9) {
                CGContextSetStrokeColorWithColor(context, [color CGColor]);
            }else if (i>9&&i<11&&type>=10) {
                CGContextSetStrokeColorWithColor(context, [color CGColor]);
            }else if (i>10&&i<12&&type>=11) {
                CGContextSetStrokeColorWithColor(context, [color CGColor]);
            }else if (i>11&&i<13&&type>=12) {
                CGContextSetStrokeColorWithColor(context, [color CGColor]);
            }else if (i>12&&i<14&&type>=13) {
                CGContextSetStrokeColorWithColor(context, [color CGColor]);
            }else if (i>13&&i<15&&type>=14) {
                CGContextSetStrokeColorWithColor(context, [color CGColor]);
            }else if (i>14&&i<16&&type>=15) {
                CGContextSetStrokeColorWithColor(context, [color CGColor]);
            }else if (i>15&&i<17&&type>=16) {
                CGContextSetStrokeColorWithColor(context, [color CGColor]);
            }else if (i>16&&i<18&&type>=17) {
                CGContextSetStrokeColorWithColor(context, [color CGColor]);
            }else if (i>17&&i<19&&type>=18) {
                CGContextSetStrokeColorWithColor(context, [color CGColor]);
            }else if (i>18&&i<20&&type>=19) {
                CGContextSetStrokeColorWithColor(context, [color CGColor]);
            }else if (i>19&&i<21&&type>=20) {
                CGContextSetStrokeColorWithColor(context, [color CGColor]);
            }else if (i>20&&i<22&&type>=21) {
                CGContextSetStrokeColorWithColor(context, [color CGColor]);
            }else if (i>21&&i<23&&type>=22) {
                CGContextSetStrokeColorWithColor(context, [color CGColor]);
            }else if (i>22&&i<24&&type>=23) {
                CGContextSetStrokeColorWithColor(context, [color CGColor]);
            }else if (i>23&&i<25&&type>=24) {
                CGContextSetStrokeColorWithColor(context, [color CGColor]);
            }else if (i>24&&i<26&&type>=25) {
                CGContextSetStrokeColorWithColor(context, [color CGColor]);
            }else if (i>25&&i<27&&type>=26) {
                CGContextSetStrokeColorWithColor(context, [color CGColor]);
            }else if (i>26&&i<28&&type>=27) {
                CGContextSetStrokeColorWithColor(context, [color CGColor]);
            }else if (i>27&&i<29&&type>=28) {
                CGContextSetStrokeColorWithColor(context, [color CGColor]);
            }else if (i>28&&i<30&&type>=29) {
                CGContextSetStrokeColorWithColor(context, [color CGColor]);
            }else if (i>29&&i<31&&type>=30) {
                CGContextSetStrokeColorWithColor(context, [color CGColor]);
            }else if (i>30&&i<32&&type>=31) {
                CGContextSetStrokeColorWithColor(context, [color CGColor]);
            }else if (i>31&&i<33&&type>=32) {
                CGContextSetStrokeColorWithColor(context, [color CGColor]);
            }else if (i>32&&i<34&&type>=33) {
                CGContextSetStrokeColorWithColor(context, [color CGColor]);
            }else if (i>33&&i<35&&type>=34) {
                CGContextSetStrokeColorWithColor(context, [color CGColor]);
            }else if (i>34&&i<36&&type>=35) {
                CGContextSetStrokeColorWithColor(context, [color CGColor]);
            }else if (i>35&&i<37&&type>=36) {
                CGContextSetStrokeColorWithColor(context, [color CGColor]);
            }else if (i>36&&i<38&&type>=37) {
                CGContextSetStrokeColorWithColor(context, [color CGColor]);
            }else if (i>37&&i<39&&type>=38) {
                CGContextSetStrokeColorWithColor(context, [color CGColor]);
            }else if (i>38&&i<40&&type>=39) {
                CGContextSetStrokeColorWithColor(context, [color CGColor]);
            }else if (i>39&&i<41&&type>=40) {
                CGContextSetStrokeColorWithColor(context, [color CGColor]);
            }else if (i>40&&i<42&&type>=41) {
                CGContextSetStrokeColorWithColor(context, [color CGColor]);
            }else if (i>41&&i<43&&type>=42) {
                CGContextSetStrokeColorWithColor(context, [color CGColor]);
            }else if (i>42&&i<44&&type>=43) {
                CGContextSetStrokeColorWithColor(context, [color CGColor]);
            }else if (i>43&&i<45&&type>=44) {
                CGContextSetStrokeColorWithColor(context, [color CGColor]);
            }else if (i>44&&i<46&&type>=45) {
                CGContextSetStrokeColorWithColor(context, [color CGColor]);
            }else if (i>45&&i<47&&type>=46) {
                CGContextSetStrokeColorWithColor(context, [color CGColor]);
            }else if (i>46&&i<48&&type>=47) {
                CGContextSetStrokeColorWithColor(context, [color CGColor]);
            }else if (i>47&&i<49&&type>=48) {
                CGContextSetStrokeColorWithColor(context, [color CGColor]);
            }else if (i>48&&i<50&&type>=49) {
                CGContextSetStrokeColorWithColor(context, [color CGColor]);
            }else if (i>49&&i<51&&type>=50) {
                CGContextSetStrokeColorWithColor(context, [color CGColor]);
            }else if (i>50&&i<52&&type>=51) {
                CGContextSetStrokeColorWithColor(context, [color CGColor]);
            }else if (i>51&&i<53&&type>=52) {
                CGContextSetStrokeColorWithColor(context, [color CGColor]);
            }else if (i>52&&i<54&&type>=53) {
                CGContextSetStrokeColorWithColor(context, [color CGColor]);
            }else if (i>53&&i<55&&type>=54) {
                CGContextSetStrokeColorWithColor(context, [color CGColor]);
            }else if (i>54&&i<56&&type>=55) {
                CGContextSetStrokeColorWithColor(context, [color CGColor]);
            }else if (i>55&&i<57&&type>=56) {
                CGContextSetStrokeColorWithColor(context, [color CGColor]);
            }else if (i>56&&i<58&&type>=57) {
                CGContextSetStrokeColorWithColor(context, [color CGColor]);
            }else if (i>57&&i<59&&type>=58) {
                CGContextSetStrokeColorWithColor(context, [color CGColor]);
            }else if (i>58&&i<60&&type>=59) {
                CGContextSetStrokeColorWithColor(context, [color CGColor]);
            }else if (i>59&&i<61&&type>=60) {
                CGContextSetStrokeColorWithColor(context, [color CGColor]);
            }else if (i>60&&i<62&&type>=61) {
                CGContextSetStrokeColorWithColor(context, [color CGColor]);
            }else if (i>61&&i<63&&type>=62) {
                CGContextSetStrokeColorWithColor(context, [color CGColor]);
            }else if (i>62&&i<64&&type>=63) {
                CGContextSetStrokeColorWithColor(context, [color CGColor]);
            }else if (i>63&&i<65&&type>=64) {
                CGContextSetStrokeColorWithColor(context, [color CGColor]);
            }else if (i>64&&i<66&&type>=65) {
                CGContextSetStrokeColorWithColor(context, [color CGColor]);
            }else if (i>65&&i<67&&type>=66) {
                CGContextSetStrokeColorWithColor(context, [color CGColor]);
            }else if (i>66&&i<68&&type>=67) {
                CGContextSetStrokeColorWithColor(context, [color CGColor]);
            }else if (i>67&&i<69&&type>=68) {
                CGContextSetStrokeColorWithColor(context, [color CGColor]);
            }else if (i>68&&i<70&&type>=69) {
                CGContextSetStrokeColorWithColor(context, [color CGColor]);
            }else if (i>69&&i<71&&type>=70) {
                CGContextSetStrokeColorWithColor(context, [color CGColor]);
            }else if (i>70&&i<72&&type>=71) {
                CGContextSetStrokeColorWithColor(context, [color CGColor]);
            }else if (i>71&&i<73&&type>=72) {
                CGContextSetStrokeColorWithColor(context, [color CGColor]);
            }else if (i>72&&i<74&&type>=73) {
                CGContextSetStrokeColorWithColor(context, [color CGColor]);
            }else if (i>73&&i<75&&type>=74) {
                CGContextSetStrokeColorWithColor(context, [color CGColor]);
            }else if (i>74&&i<76&&type>=75) {
                CGContextSetStrokeColorWithColor(context, [color CGColor]);
            }else if (i>75&&i<77&&type>=76) {
                CGContextSetStrokeColorWithColor(context, [color CGColor]);
            }else if (i>76&&i<78&&type>=77) {
                CGContextSetStrokeColorWithColor(context, [color CGColor]);
            }else if (i>77&&i<79&&type>=78) {
                CGContextSetStrokeColorWithColor(context, [color CGColor]);
            }else if (i>78&&i<80&&type>=79) {
                CGContextSetStrokeColorWithColor(context, [color CGColor]);
            }else if (i>79&&i<81&&type>=80) {
                CGContextSetStrokeColorWithColor(context, [color CGColor]);
            }
            else{
                CGContextSetStrokeColorWithColor(context, [[UIColor colorWithRed:1 green:1 blue:1 alpha:0.3] CGColor]);
            }
        }else{
            CGContextSetStrokeColorWithColor(context, [[UIColor colorWithRed:1 green:1 blue:1 alpha:0.3] CGColor]);
            
        }

        
        
        
        
        
        //绘制不同的长短的刻度
        if(i%10==0)
        {
            CGContextSetLineCap(context, kCGLineCapSquare);
            CGContextSetLineWidth(context, 1);
            CGContextStrokePath(context);
            if (iPhone6plus||iPhone6PlusZoomMode) {
                CGContextMoveToPoint(context,centerPoint.x+[self parseToX:radius-40*scoleNum Angle:currentAngle], centerPoint.y+[self parseToY:radius-40*scoleNum Angle:currentAngle]);
                CGContextAddLineToPoint(context,centerPoint.x+[self parseToX:radius-28*scoleNum Angle:currentAngle], centerPoint.y+[self parseToY:radius-28*scoleNum Angle:currentAngle]);
            }else if (iPhone6){
                CGContextMoveToPoint(context,centerPoint.x+[self parseToX:radius-40*scoleNum Angle:currentAngle], centerPoint.y+[self parseToY:radius-40*scoleNum Angle:currentAngle]);
                CGContextAddLineToPoint(context,centerPoint.x+[self parseToX:radius-28*scoleNum Angle:currentAngle], centerPoint.y+[self parseToY:radius-28*scoleNum Angle:currentAngle]);
            }else if (iPhone5){
                CGContextMoveToPoint(context,centerPoint.x+[self parseToX:radius-38*scoleNum Angle:currentAngle], centerPoint.y+[self parseToY:radius-38*scoleNum Angle:currentAngle]);
                CGContextAddLineToPoint(context,centerPoint.x+[self parseToX:radius-30*scoleNum Angle:currentAngle], centerPoint.y+[self parseToY:radius-30*scoleNum Angle:currentAngle]);
            }else{
                CGContextMoveToPoint(context,centerPoint.x+[self parseToX:radius-38*scoleNum Angle:currentAngle], centerPoint.y+[self parseToY:radius-38*scoleNum Angle:currentAngle]);
                CGContextAddLineToPoint(context,centerPoint.x+[self parseToX:radius-30*scoleNum Angle:currentAngle], centerPoint.y+[self parseToY:radius-30*scoleNum Angle:currentAngle]);
            }
        }else{
            CGContextSetLineWidth(context, 1);
            CGContextSetLineCap(context, kCGLineCapSquare);
            CGContextStrokePath(context);
            
            
        CGContextMoveToPoint(context,centerPoint.x+[self parseToX:radius-32*scoleNum Angle:currentAngle], centerPoint.y+[self parseToY:radius-32*scoleNum Angle:currentAngle]);
            if (iPhone6plus||iPhone6PlusZoomMode) {

                CGContextAddLineToPoint(context,centerPoint.x+[self parseToX:radius-40*scoleNum Angle:currentAngle], centerPoint.y+[self parseToY:radius-40*scoleNum Angle:currentAngle]);
            }else if (iPhone6){
                
                CGContextAddLineToPoint(context,centerPoint.x+[self parseToX:radius-40*scoleNum Angle:currentAngle], centerPoint.y+[self parseToY:radius-40*scoleNum Angle:currentAngle]);
            }else if (iPhone5){
                
                CGContextAddLineToPoint(context,centerPoint.x+[self parseToX:radius-38*scoleNum Angle:currentAngle], centerPoint.y+[self parseToY:radius-38*scoleNum Angle:currentAngle]);
            }else{
                
                CGContextAddLineToPoint(context,centerPoint.x+[self parseToX:radius-38*scoleNum Angle:currentAngle], centerPoint.y+[self parseToY:radius-38*scoleNum Angle:currentAngle]);
            }
            

            

            
        }
   
        
        if (i==0||i==10||i==20||i==30||i==40||i==50||i==60||i==70||i==80) {
            CGContextSetLineCap(context, kCGLineCapSquare);
            CGContextSetLineWidth(context, 2);
            CGContextStrokePath(context);
        }
        
    }
}


/*
 * setGaugeValue 移动到某个数值
 * @value CGFloat 移动到的数值
 * @isAnim BOOL   是否执行动画
 */
-(void)setGaugeValue:(CGFloat)value animation:(BOOL)isAnim
{
    NSString *stringFloat = [NSString stringWithFormat:@"%f",value];
    int temp = [stringFloat intValue];
    if (temp == 0)
    {   value = 0;
    }else if (temp>0&&temp<=25.6){
        value = 1;
    } else if (temp>25.6&&temp<=51.2){
        value=2;
    }else if (temp>51.2&&temp<=76.8){
        value=3;
    }else if (temp>76.8&&temp<=102.4){
        value=4;
    }else if (temp>102.4&&temp<=128.0){
        value=5;
    }else if (temp>128.0&&temp<=153.6){
        value=6;
    }else if (temp>153.6&&temp<=179.2){
        value=7;
    }else if (temp>179.2&&temp<=204.8){
        value=8;
    }else if (temp>204.8&&temp<=230.4){
        value=9;
    }else if (temp>230.4&&temp<=256){
        value=10;
    }else if (temp>256&&temp<=281.6){
        value=11;
    }else if (temp>281.6&&temp<=307.2){
        value=12;
    }else if (temp>307.2&&temp<=332.8){
        value=13;
    }else if (temp>332.8&&temp<=358.4){
        value=14;
    }else if (temp>358.4&&temp<=384.0){
        value=15;
    }else if (temp>384.0&&temp<=409.6){
        value=16;
    }else if (temp>409.6&&temp<=435.2){
        value=17;
    }else if (temp>435.2&&temp<=460.8){
        value=18;
    }else if (temp>460.8&&temp<=486.4){
        value=19;
    }else if (temp>486.4&&temp<=512.0){
        value=20;
    }else if (temp>512.0&&temp<=563.2){
        value=21;
    }else if (temp>563.2&&temp<=614.4){
        value=22;
    }else if (temp>614.4&&temp<=665.6){
        value=23;
    }else if (temp>665.6&&temp<=716.8){
        value=24;
    }else if (temp>716.8&&temp<=768.0){
        value=25;
    }else if (temp>768.0&&temp<=819.2){
        value=26;
    }else if (temp>819.2&&temp<=870.4){
        value=27;
    }else if (temp>870.4&&temp<=921.6){
        value=28;
    }else if (temp>921.6&&temp<=972.8){
        value=29;
    }else if (temp>972.8&&temp<=1024.0){
        value=30;
    }else if (temp>1024.0&&temp<=1433.6){
        value=31;
    }else if (temp>1433.6&&temp<=1843.2){
        value=32;
    }else if (temp>1843.2&&temp<=2252.8){
        value=33;
    }else if (temp>2252.8&&temp<=2662.4){
        value=34;
    }else if (temp>2662.4&&temp<=3072.0){
        value=35;
    }else if (temp>3072.0&&temp<=3481.6){
        value=36;
    }else if (temp>3481.6&&temp<=3891.2){
        value=37;
    }else if (temp>3891.2&&temp<=4300.8){
        value=38;
    }else if (temp>4300.8&&temp<=4710.4){
        value=39;
    }else if (temp>4710.4&&temp<=5120.0){
        value=40;
    }else if (temp>5120.0&&temp<=5632.0){
        value=41;
    }else if (temp>5632.0&&temp<=6144.0){
        value=42;
    }else if (temp>6144.0&&temp<=6656.0){
        value=43;
    }else if (temp>6656.0&&temp<=7168.0){
        value=44;
    }else if (temp>7168.0&&temp<=7680.0){
        value=45;
    }else if (temp>7680.0&&temp<=8192.0){
        value=46;
    }else if (temp>8192.0&&temp<=8704.0){
        value=47;
    }else if (temp>8704.0&&temp<=9216.0){
        value=48;
    }else if (temp>9216.0&&temp<=9728.0){
        value=49;
    }else if (temp>9728.0&&temp<=10240.0){
        value=50;
    }else if (temp>10240.0&&temp<=11264.0){
        value=51;
    }else if (temp>11264.0&&temp<=12288.0){
        value=52;
    }else if (temp>12288.0&&temp<=13312.0){
        value=53;
    }else if (temp>13312.0&&temp<=14336.0){
        value=54;
    }else if (temp>14336.0&&temp<=15360.0){
        value=55;
    }else if (temp>15360.0&&temp<=16384.0){
        value=56;
    }else if (temp>16384.0&&temp<=17408.0){
        value=57;
    }else if (temp>17408.0&&temp<=18432.0){
        value=58;
    }else if (temp>18432.0&&temp<=19456.0){
        value=59;
    }else if (temp>19456.0&&temp<=20480.0){
        value=60;
    }else if (temp>20480.0&&temp<=23552.0){
        value=61;
    }else if (temp>23552.0&&temp<=26624.0){
        value=62;
    }else if (temp>26624.0&&temp<=29696.0){
        value=63;
    }else if (temp>29696.0&&temp<=32768.0){
        value=64;
    }else if (temp>32768.0&&temp<=35840.0){
        value=65;
    }else if (temp>35840.0&&temp<=38912.0){
        value=66;
    }else if (temp>38912.0&&temp<=41984.0){
        value=67;
    }else if (temp>41984.0&&temp<=45056.0){
        value=68;
    }else if (temp>45056.0&&temp<=48128.0){
        value=69;
    }else if (temp>48128.0&&temp<=51200.0){
        value=70;
    }else if (temp>51200.0&&temp<=56320.0){
        value=71;
    }else if (temp>56320.0&&temp<=61440.0){
        value=72;
    }else if (temp>61440.0&&temp<=66560.0){
        value=73;
    }else if (temp>66560.0&&temp<=71680.0){
        value=74;
    }else if (temp>71680.0&&temp<=76800.0){
        value=75;
    }else if (temp>76800.0&&temp<=81920.0){
        value=76;
    }else if (temp>81920.0&&temp<=87040.0){
        value=77;
    }else if (temp>87040.0&&temp<=92160.0){
        value=78;
    }else if (temp>92160.0&&temp<=97280.0){
        value=79;
    }else if (temp>97280.0&&temp<=102400){
        value=80;
    }else if (temp>102400){
        value=80;
    }
    CGFloat tempAngle = [self parseToAngle:value];
    gaugeValue = value;
    //设置转动时间和转动动画
    if(isAnim)
    {
        [self pointToAngle:tempAngle Duration:1.0f];
    }
    else
    {
        [self pointToAngle:tempAngle Duration:0.0f];
    }
  
//    NSTimeInterval period = 0.7; //设置时间间隔
//    
//    dispatch_queue_t queue = dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0);
//    dispatch_source_t _timer = dispatch_source_create(DISPATCH_SOURCE_TYPE_TIMER, 0, 0, queue);
//    dispatch_source_set_timer(_timer, dispatch_walltime(NULL, 0), (int64_t)period * NSEC_PER_SEC, 0); //每秒执行
//    
//    dispatch_source_set_event_handler(_timer, ^{
//        //在这里执行事件
//        
//    });

//    dispatch_resume(_timer);
    double delayInSeconds = 0.123;
//    __block Gauge* bself = self;
    dispatch_time_t popTime = dispatch_time(DISPATCH_TIME_NOW, (int64_t)(delayInSeconds * NSEC_PER_SEC));
    dispatch_after(popTime, dispatch_get_main_queue(), ^(void){
    [self setNeedsDisplay];
    });
    
//    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.132* NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
//
//    });
}



/*
 * pointToAngle 按角度旋转
 * @angel CGFloat 角度
 * @duration CGFloat 动画执行时间
 */
- (void) pointToAngle:(CGFloat) angle Duration:(CGFloat) duration
{
    CAKeyframeAnimation *anim=[CAKeyframeAnimation animationWithKeyPath:@"transform"];
    NSMutableArray *values=[NSMutableArray array];
    anim.duration = duration;
    anim.delegate=self;
    anim.autoreverses = NO;
    anim.calculationMode = kCAMediaTimingFunctionLinear;
    anim.fillMode = kCAFillModeForwards;
    anim.removedOnCompletion= NO;
    CGFloat distance = angle/10;

    
    //设置转动路径，不能直接用 CABaseAnimation 的toValue，那样是按最短路径的，转动超过180度时无法控制方向
    int i = 1;
    for(;i<=10;i++)
    {
        [values addObject:[NSValue valueWithCATransform3D:CATransform3DRotate(CATransform3DIdentity, [self transToRadian:(gaugeAngle+distance*i)], 0, 0, 1)]];

    }
    //添加缓动效果
//    [values addObject:[NSValue valueWithCATransform3D:CATransform3DRotate(CATransform3DIdentity, [self transToRadian:(gaugeAngle+distance*(i))], 0, 0, 1)]];
//    [values addObject:[NSValue valueWithCATransform3D:CATransform3DRotate(CATransform3DIdentity, [self transToRadian:(gaugeAngle+distance*(i-2))], 0, 0, 1)]];
//    [values addObject:[NSValue valueWithCATransform3D:CATransform3DRotate(CATransform3DIdentity, [self transToRadian:(gaugeAngle+distance*(i-1))], 0, 0, 1)]];
    
    anim.values=values;
    [pointer.layer addAnimation:anim forKey:@"cubeIn"];
    gaugeAngle = gaugeAngle+angle;
  trigger=YES;
}




-(void)animationDidStop:(CAAnimation *)theAnimation finished:(BOOL)flag {
//NSLog(@"执行结束");
//    [self setNeedsDisplay];

}
- (void)animationDidStart:(CAAnimation *)anim
{
// __weak Gauge * weekSelf = self;
//[UIView transitionWithView:self duration:anim.duration options:UIViewAnimationOptionAllowAnimatedContent animations:^{
//     [weekSelf setLineMark:MAXVALUE];
//}
//                completion:^(BOOL finished) {
//           [weekSelf setNeedsDisplay]
//                    NSLog(@"开始");
    
//                }];
 
//
//    NSLog(@"=================%f",anim.duration);
//    [self setLineMark:MAXVALUE];
//    [UIView animateWithDuration:2 animations:^{
//        
//    }completion:^(BOOL finished) {
//
//    }];
//    
//        NSLog(@"--------------------");
}

/*
 * parseToX 角度转弧度
 * @angel CGFloat 角度
 */
-(CGFloat)transToRadian:(CGFloat)angel
{
    return angel*M_PI/180;
}

/*
 * parseToX 根据角度，半径计算X坐标
 * @radius CGFloat 半径
 * @angle  CGFloat 角度
 */
- (CGFloat) parseToX:(CGFloat) radius Angle:(CGFloat)angle
{
    CGFloat tempRadian = [self transToRadian:angle];
    return radius*cos(tempRadian);
}

/*
 * parseToY 根据角度，半径计算Y坐标
 * @radius CGFloat 半径
 * @angle  CGFloat 角度
 */
- (CGFloat) parseToY:(CGFloat) radius Angle:(CGFloat)angle
{
    CGFloat tempRadian = [self transToRadian:angle];
    return radius*sin(tempRadian);
}

/*
 * parseToAngle 根据数据计算需要转动的角度
 * @val CGFloat 要移动到的数值
 */
-(CGFloat) parseToAngle:(CGFloat) val
{
	//异常的数据
	if(val<minNum)
    {
		return minNum;
	}
    else if(val>maxNum)
    {
		return maxNum;
	}
	CGFloat temp =(val-gaugeValue)*angleperValue;
	return temp;
}

/*
 * parseToValue 根据角度计算数值
 * @val CGFloat 要移动到的角度
 */
-(CGFloat) parseToValue:(CGFloat) val
{
	CGFloat temp=val/angleperValue;
	CGFloat temp2=maxNum/2+temp;
	if(temp2>maxNum)
    {
		return maxNum;
	}
    else if(temp2<maxNum)
    {
		return maxNum;
	}
	return temp2;
}

- (void)drawRect:(CGRect)rect
{
    //获取上下文
    context = UIGraphicsGetCurrentContext();
    //设置背景透明
    CGContextSetFillColorWithColor(context,self.backgroundColor.CGColor);
	CGContextFillRect(context, rect);
    //绘制仪表背景
    [[self gaugeView] drawInRect:self.bounds];
    //绘制刻度
    [self setLineMark:MAXVALUE];
    
	CGContextStrokePath(context);
}

@end
