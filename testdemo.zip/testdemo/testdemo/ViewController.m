//
//  ViewController.m
//  testdemo
//
//  Created by wangzhewei on 16/2/27.
//  Copyright © 2016年 wangzhewei. All rights reserved.
//

#import "ViewController.h"
#import "Gauge.h"
@interface ViewController ()
@property (nonatomic,strong)Gauge *gauageview;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self createGauageView];
    
    [NSTimer scheduledTimerWithTimeInterval:1.0 target:self selector:@selector(timeRunning) userInfo:nil repeats:YES];
}


- (void)createGauageView
{
    self.gauageview=[[Gauge alloc] initWithFrame:CGRectMake(0, 0, self.view.bounds.size.width,self.view.bounds.size.width)];
     self.gauageview.center=self.view.center;
    [self.view addSubview:self.gauageview];
}


- (void)timeRunning
{
    [self.gauageview setGaugeValue:arc4random_uniform(102400) animation:YES];    
}



- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
